import React, {Component} from 'react';

class Header extends Component{
    render() { 
        return (
            <div className="card-header bg-info text-center">
				<b>
					Informasi Dormitory Chatbot
				</b>
			</div>
         );
    }
}
 
export default Header;


